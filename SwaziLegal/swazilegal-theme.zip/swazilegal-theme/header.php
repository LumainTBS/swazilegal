<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<header>
    <div class="header-container">
        <div class="logo">
            <div class="logo-icon"><i class="fas fa-gavel"></i></div>
            <span><?php bloginfo( 'name' ); ?></span>
        </div>
        <nav>
            <?php
            wp_nav_menu( array(
                'theme_location' => 'primary',
                'container'      => false,
                'menu_id'        => 'nav-menu',
                'fallback_cb'    => 'swazilegal_fallback_menu',
            ) );
            
            function swazilegal_fallback_menu() {
                ?>
                <ul id="nav-menu">
                    <li><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><i class="fas fa-home"></i> Home</a></li>
                    <li><a href="<?php echo esc_url( home_url( '/about' ) ); ?>"><i class="fas fa-info-circle"></i> About</a></li>
                    <li><a href="<?php echo esc_url( home_url( '/practices' ) ); ?>"><i class="fas fa-balance-scale"></i> Practice Areas</a></li>
                    <li><a href="<?php echo esc_url( home_url( '/services' ) ); ?>"><i class="fas fa-concierge-bell"></i> Services</a></li>
                    <li><a href="<?php echo esc_url( home_url( '/team' ) ); ?>"><i class="fas fa-users"></i> Our Team</a></li>
                    <li><a href="<?php echo esc_url( home_url( '/contact' ) ); ?>"><i class="fas fa-envelope"></i> Contact</a></li>
                </ul>
                <?php
            }
            ?>
        </nav>
    </div>
</header>

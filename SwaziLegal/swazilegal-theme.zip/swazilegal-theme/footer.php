<footer>
    <div class="footer-container">
        <div class="footer-grid">
            <div class="footer-section">
                <h4><?php bloginfo( 'name' ); ?></h4>
                <p style="color: rgba(255,255,255,0.8); margin-bottom: 1rem;">
                    <?php bloginfo( 'description' ); ?>
                </p>
            </div>
            <div class="footer-section">
                <h4>Quick Links</h4>
                <?php
                wp_nav_menu( array(
                    'theme_location' => 'footer',
                    'container'      => false,
                ) );
                ?>
            </div>
            <div class="footer-section">
                <h4>Connect</h4>
                <ul>
                    <li><i class="fab fa-whatsapp"></i> WhatsApp Confirmation</li>
                    <li><i class="fas fa-phone"></i> Direct Consultation</li>
                </ul>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; <?php echo date('Y'); ?> <?php bloginfo( 'name' ); ?>. All rights reserved.</p>
        </div>
    </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
